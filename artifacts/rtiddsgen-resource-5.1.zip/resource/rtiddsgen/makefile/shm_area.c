char* shm_area_name = "RTINDDS_ShmArea";
char* shm_area_password = "******";
